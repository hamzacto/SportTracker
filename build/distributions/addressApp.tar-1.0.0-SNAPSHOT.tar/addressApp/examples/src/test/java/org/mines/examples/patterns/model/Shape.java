package org.mines.examples.patterns.model;

public interface Shape {

    String getName();
}
