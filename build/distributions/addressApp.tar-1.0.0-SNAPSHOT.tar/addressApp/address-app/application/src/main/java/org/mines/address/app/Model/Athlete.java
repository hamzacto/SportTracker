package org.mines.address.app.Model;

public class Athlete {
    private Integer id;
    private Float weight;
    private Integer age;
    private Float height;
    private String first_name;
    private String last_name;
    private Integer sport_level;
    private Float heartbeat;
    private Float blood_pressure;

    
}
