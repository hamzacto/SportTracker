INSERT INTO gym (id, name, address, pricing)
VALUES (2, 'Nom de la salle de sport', 'Adresse de la salle de sport', 50.0);
