package org.mines.examples;

public record ImmutableRecordInJava17(String value, int intValue) {
}
